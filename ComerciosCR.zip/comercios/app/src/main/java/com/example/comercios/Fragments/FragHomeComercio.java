package com.example.comercios.Fragments;


        import android.graphics.Bitmap;
        import android.os.Bundle;
        import android.app.Fragment;
        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ImageView;
        import android.widget.RatingBar;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.android.volley.AuthFailureError;
        import com.android.volley.Request;
        import com.android.volley.Response;
        import com.android.volley.VolleyError;
        import com.android.volley.toolbox.ImageRequest;
        import com.android.volley.toolbox.JsonObjectRequest;
        import com.example.comercios.Global.GlobalComercios;
        import com.example.comercios.Modelo.Categorias;
        import com.example.comercios.Modelo.Util;
        import com.example.comercios.Modelo.VolleySingleton;
        import com.example.comercios.R;
        import com.jaredrummler.materialspinner.MaterialSpinner;

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;

        import java.math.BigDecimal;
        import java.math.RoundingMode;
        import java.util.ArrayList;
        import java.util.HashMap;
        import java.util.Map;

        import androidx.appcompat.app.AppCompatActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragHomeComercio extends Fragment {

    JsonObjectRequest jsonObjectRequest;
    JsonObjectRequest jsonObjectRequest2;

    ImageView fotoComercioHome;
    TextView Usuario, Descripcion,Telefono,Categoria;
    String SUrlImagen;

    JsonObjectRequest jsonObjectRequest3;
    ArrayList<Double> calificaciones;
    RatingBar ratingBarCali;

    public FragHomeComercio() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mensajeAB(Util.nombreApp);
        View view = inflater.inflate(R.layout.frag_home_comercio, container, false);
        GlobalComercios.getInstance().setVentanaActual(R.layout.frag_home_comercio);
        fotoComercioHome = (ImageView) view.findViewById(R.id.FHomComercio_ImgLocal);
        Usuario = (TextView) view.findViewById(R.id.FHomComercio_viewUsuario);
        Descripcion =(TextView) view.findViewById(R.id.FHomComercio_viewDescripcion);
        Categoria = (TextView)view.findViewById(R.id.FHomComercio_viewCategoria);
        Telefono = (TextView) view.findViewById(R.id.FHomComercio_viewTelefono);
        Usuario.setText(GlobalComercios.getInstance().getComercio().getUsuario());
        Descripcion.setText(GlobalComercios.getInstance().getComercio().getDescripcion());
        Telefono.setText(Long.toString(GlobalComercios.getInstance().getComercio().getTelefono()));
        Categoria.setText(GlobalComercios.getInstance().getComercio().getCategoria());
        cargarWebServicesImagen2(Util.urlWebService + "/" + GlobalComercios.getInstance().getComercio().getUrlImagen());
        ratingBarCali = (RatingBar)view.findViewById(R.id.FHomComercio_ratingBar);
        recuperarCalificacionesComercio();
        return view;
    }

    private void cargarWebServicesImagen2(String ruta_foto) {
        ImageRequest imagR = new ImageRequest(ruta_foto, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {
                fotoComercioHome.setImageBitmap(response);
            }
        }, 0, 0, ImageView.ScaleType.CENTER, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Mensaje("No se encontro la imagen");
            }
        });
        VolleySingleton.getIntanciaVolley(getActivity()).addToRequestQueue(imagR);
    }
    public void Mensaje(String msg){
        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
    }

    public void recuperarCalificacionesComercio(){
        calificaciones = new ArrayList<>();
        String url = Util.urlWebService + "/obtenerCalificaciones.php?id="+GlobalComercios.getInstance().getComercio().getId();

        jsonObjectRequest3 = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonCalificaciones = response.getJSONArray("calificaciones");
                    JSONObject objeto;
                    for(int i= 0;i<jsonCalificaciones.length();i++) {
                        objeto= jsonCalificaciones.getJSONObject(i);
                        calificaciones.add(objeto.getDouble("calificacion"));
                    }
                    double suma=0;
                    for(int i=0;i<calificaciones.size();i++){
                        suma=suma+calificaciones.get(i);
                    }
                    float prueba = (float)(suma/calificaciones.size());
                    ratingBarCali.setRating((float)prueba);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Mensaje(error.toString());
            }
        });

        VolleySingleton.getIntanciaVolley(getActivity()).addToRequestQueue(jsonObjectRequest3);

    }

    private void mensajeAB(String msg){((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(msg);};

}
